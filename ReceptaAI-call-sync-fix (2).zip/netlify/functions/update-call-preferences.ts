import { createClient } from '@supabase/supabase-js'

const DEFAULT_OPERATING_HOURS = [
  { day: 'Monday', open: true, start: '09:00', end: '17:00' },
  { day: 'Tuesday', open: true, start: '09:00', end: '17:00' },
  { day: 'Wednesday', open: true, start: '09:00', end: '17:00' },
  { day: 'Thursday', open: true, start: '09:00', end: '17:00' },
  { day: 'Friday', open: true, start: '09:00', end: '17:00' },
  { day: 'Saturday', open: false, start: '09:00', end: '17:00' },
  { day: 'Sunday', open: false, start: '09:00', end: '17:00' },
]

const json = (
  status: number,
  body: Record<string, unknown>
) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  })

const hasConfiguredSchedule = (
  businessHours?: string | null
) => {
  const normalized = businessHours?.trim().toLowerCase()

  return Boolean(
    normalized &&
      normalized !== 'not configured' &&
      normalized !== 'not required'
  )
}

export default async (request: Request) => {
  if (request.method !== 'POST') {
    return json(405, { error: 'Method not allowed.' })
  }

  const supabaseUrl = process.env.SUPABASE_URL
  const supabaseSecretKey = process.env.SUPABASE_SECRET_KEY

  if (!supabaseUrl || !supabaseSecretKey) {
    return json(500, {
      error: 'Server configuration is missing.',
    })
  }

  const authHeader = request.headers.get('authorization')

  if (!authHeader?.startsWith('Bearer ')) {
    return json(401, { error: 'Unauthorized.' })
  }

  let body: { useSchedule?: boolean }

  try {
    body = await request.json()
  } catch {
    return json(400, { error: 'Invalid request body.' })
  }

  if (typeof body.useSchedule !== 'boolean') {
    return json(400, {
      error: 'Schedule preference is required.',
    })
  }

  const supabaseAdmin = createClient(
    supabaseUrl,
    supabaseSecretKey,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  )

  const {
    data: { user },
    error: userError,
  } = await supabaseAdmin.auth.getUser(
    authHeader.slice('Bearer '.length)
  )

  if (userError || !user) {
    return json(401, { error: 'Unauthorized.' })
  }

  const { data: agent, error: agentError } = await supabaseAdmin
    .from('agents')
    .select('business_hours')
    .eq('client_id', user.id)
    .maybeSingle()

  if (agentError || !agent) {
    return json(404, {
      error: 'No receptionist is assigned to this customer.',
    })
  }

  const businessHours = body.useSchedule
    ? hasConfiguredSchedule(agent.business_hours)
      ? agent.business_hours
      : JSON.stringify(DEFAULT_OPERATING_HOURS)
    : 'Not required'

  const { error: updateError } = await supabaseAdmin
    .from('agents')
    .update({ business_hours: businessHours })
    .eq('client_id', user.id)

  if (updateError) {
    return json(500, {
      error: 'Could not save the schedule preference.',
    })
  }

  return json(200, {
    scheduleEnabled: body.useSchedule,
    businessHours,
  })
}
